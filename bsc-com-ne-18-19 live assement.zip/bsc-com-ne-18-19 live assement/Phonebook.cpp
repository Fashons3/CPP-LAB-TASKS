#include "phonebook.h"

Phonebook::Phonebook() : num_valid_contacts(0), max_contacts(5) {}

void Phonebook::addContact(const std::string& name, const std::string& phone_number) {
  if (num_valid_contacts < max_contacts) {
    contacts.push_back(Contact(name, phone_number));
    ++num_valid_contacts;
    std::cout << "Contact added successfully!" << std::endl;
  } else {
    std::cerr << "Phonebook is full. Cannot add more contacts." << std::endl;
  }
}

void Phonebook::saveContactsToFile(const std::string& filename) const {
  std::ofstream outfile(filename);
  if (outfile.is_open()) {
    for (int i = 0; i < num_valid_contacts; ++i) {
      outfile << contacts[i].name << "," << contacts[i].phone_number << std::endl;
    }
    outfile.close();
    std::cout << "Contacts saved to file: " << filename << std::endl;
  } else {
    std::cerr << "Error opening file for saving contacts." << std::endl;
  }
}

void Phonebook::showAllContacts() const {
  if (num_valid_contacts == 0) {
    std::cout << "There are no contacts in the phonebook." << std::endl;
    return;
  }

  std::cout << "Contacts:\n";
  for (int i = 0; i < num_valid_contacts; ++i) {
    std::cout << "  - " << contacts[i].name << ": " << contacts[i].phone_number << std::endl;
  }
}

void Phonebook::run() 
{
  int choice;
  std::string name, phone_number, filename;

  do {
    std::cout << "\nPhonebook Menu:\n";
    std::cout << "1. Add Contact\n";
    std::cout << "2. Show All Contacts\n";
    std::cout << "3. Save Contacts to File\n";
    std::cout << "4. Exit\n";
    std::cout << "Enter your choice: ";
    std::cin >> choice;

    switch (choice) {
      case 1:
        std::cout << "Enter name: ";
        std::cin.ignore(); 
        std::getline(std::cin, name);
        std::cout << "Enter phone number: ";
        std::getline(std::cin, phone_number);
        addContact(name, phone_number);
        break;
      case 2:
        showAllContacts();
        break;
      case 3:
        std::cout << "Enter filename to save contacts: ";
        std::cin >> filename;
        saveContactsToFile(filename);
        break;
      case 4:
        std::cout << "Exiting phonebook...\n";
        break;
      default:
        std::cerr << "Invalid choice. Please try again.\n";
    }
  } while (true);
}