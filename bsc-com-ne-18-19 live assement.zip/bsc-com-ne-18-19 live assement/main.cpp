#include <iostream>
#include "Phonebook.h" 

using namespace std;

int main() {
    Phonebook phonebook = Phonebook();
    phonebook.run();  
    return 0;
}
