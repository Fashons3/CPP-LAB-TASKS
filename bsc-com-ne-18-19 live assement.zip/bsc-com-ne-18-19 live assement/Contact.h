#ifndef CONTACT_H
#define CONTACT_H

#include <string>

class Contact {
public:
    
    Contact();

   
    Contact(const std::string& mfirstName, const std::string& mlastName, const std::string& mphoneNumber);

   
    const std::string& getmFirstName() const;
    void setFirstName(const std::string& firstName);

    const std::string& getmLastName() const;
    void setLastName(const std::string& lastName);

    const std::string& getmPhoneNumber() const;
    void setPhoneNumber(const std::string& phoneNumber);

    
    bool operator==(const Contact& other) const;

private:
    std::string mfirstName;
    std::string mlastName;
    std::string mphoneNumber;
};

#endif