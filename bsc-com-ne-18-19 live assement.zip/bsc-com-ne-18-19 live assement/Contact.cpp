#include "Contact.h"
#include <iostream>

using namespace std;

Contact::Contact() : mfirstName(""), mlastName(""), mphoneNumber("") {}


Contact::Contact(const string& firstName, const string& lastName, const string& phoneNumber) :
    mfirstName(firstName), mlastName(lastName), mphoneNumber(phoneNumber) {}


const string& Contact::getmFirstName() const { return mfirstName; }
void Contact::setFirstName(const string& firstName) { this->mfirstName = firstName; }

const string& Contact::getmLastName() const { return mlastName; }
void Contact::setLastName(const string& lastName) { this->mlastName = lastName; }

const string& Contact::getmPhoneNumber() const { return mphoneNumber; }
void Contact::setPhoneNumber(const string& phoneNumber) { this->mphoneNumber = phoneNumber; }


bool Contact::operator==(const Contact& other) const {
    return mphoneNumber == other.mphoneNumber;
}
